const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
var userModel = require("../Models/UserModel");
const Response = require("../Helpers/Response");
const { validationResult } = require("express-validator");
const Global = require("../Helpers/Global");
var objectID = mongoose.Types.ObjectId;

const getCustomerInfo = async (req, res, next) => {
  var result = validationResult(req);
  if (!result.isEmpty()) {
    return Response.error(res, result.array()[0].msg);
  }
  var userData = await userModel.findByEmail(req.user.email);
  userData = Global.convertObject(userData);
  if (userData.role === "Customer") {
    var userDataFinal = Global.omit(userData, [
      "password",
      "otp",
      "token",
      "active",
      "createdAt",
      "mobileVerified",
      "emailVerified",
      "adminVerified",
    ]);
    if (userData)
      return Response.ok(res, "Data retrived successfully.", userDataFinal);
  } else {
    Response.unauthorize(res, "Unauthorized user access.", userDataFinal);
  }
};

const getProviderInfo = async (req, res, next) => {
  var result = validationResult(req);
  if (!result.isEmpty()) {
    return Response.error(res, result.array()[0].msg);
  }
  var userData = await userModel.findByEmail(req.user.email);
  userData = Global.convertObject(userData);
  if (userData.role === "Provider") {
    var userDataFinal = Global.omit(userData, [
      "password",
      "otp",
      "token",
      "active",
      "createdAt",
      "mobileVerified",
      "emailVerified",
      "adminVerified",
    ]);
    if (userData)
      return Response.ok(res, "Data retrived successfully.", userDataFinal);
  } else {
    Response.unauthorize(res, "Unauthorized user access.", userDataFinal);
  }
};

const getUserInfo = async (req, res, next) => {
  var result = validationResult(req);
  if (!result.isEmpty()) {
    return Response.error(res, result.array()[0].msg);
  }
  var userData = await userModel.findByEmail(req.user.email);
  userData = Global.convertObject(userData);
  if (userData.role === req.user.role) {
    var userDataFinal = Global.omit(userData, [
      "password",
      "otp",
      "token",
      "active",
      "createdAt",
      "mobileVerified",
      "emailVerified",
      "adminVerified",
    ]);
    if (userData)
      return Response.ok(res, "Data retrived successfully.", userDataFinal);
  } else {
    Response.unauthorize(res, "Unauthorized user access.", userDataFinal);
  }
};



module.exports = {
  getCustomerInfo,
  getProviderInfo,
  getUserInfo,
};
